import edu.princeton.cs.algs4.Picture;
import java.awt.Color;

public class SeamCarver {
    private Picture picture;
    private double[][] energy;

    /**
     * create a seam carver object based on the given picture.
     */
    public SeamCarver(Picture picture) {
        if (picture == null) {
            throw new java.lang.IllegalArgumentException();
        }

        this.picture = new Picture(picture);
        energy = calcEnergy(picture);
    }

    private static double[][] calcEnergy(Picture picture) {
        int width = picture.width();
        int height = picture.height();
        double[][] energy = new double[width][height];

        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                if (x == 0 || x == width - 1 || y == 0 || y == height - 1) {
                    energy[x][y] = 1000;
                } else {
                    energy[x][y] = Math.sqrt(xGradient(picture, x, y) + yGradient(picture, x, y));
                }
            }
        }
        return energy;
    }

    private static double xGradient(Picture picture, int x, int y) {
        Color left = picture.get(x - 1, y);
        Color right = picture.get(x + 1, y);
        int dR = left.getRed() - right.getRed();
        int dG = left.getGreen() - right.getGreen();
        int dB = left.getBlue() - right.getBlue();
        return dR * dR + dG * dG + dB * dB;
    }


    private static double yGradient(Picture picture, int x, int y) {
        Color up = picture.get(x, y - 1);
        Color down = picture.get(x, y + 1);
        int dR = up.getRed() - down.getRed();
        int dG = up.getGreen() - down.getGreen();
        int dB = up.getBlue() - down.getBlue();
        return dR * dR + dG * dG + dB * dB;
    }

    /**
     * current picture.
     */
    public Picture picture() {
        return new Picture(picture);
    }

    /**
     * width of current picture.
     */
    public int width() {
        return picture.width();
    }

    /**
     * height of current picture.
     */
    public int height() {
        return picture.height();
    }

    /**
     * energy of pixel at column x and row y.
     */
    public double energy(int x, int y) {
        if (!isValid(x, y)) {
            throw new java.lang.IllegalArgumentException();
        }

        return energy[x][y];
    }

    /**
     * sequence of indices for Vertical seam.
     */
    public int[] findVerticalSeam() {
        double[][] distTo = new double[width()][height()];
        int[][] edgeTo = new int[width()][height()];
        int[] verticalSeam = new int[height()];
        int seamEnd = 0;

        for (int x = 0; x < width(); x++) {
            for (int y = 0; y < height(); y++) {
                if (y == 0) {
                    distTo[x][y] = 1000;
                } else {
                    distTo[x][y] = Double.POSITIVE_INFINITY;
                }
            }
        }

        for (int y = 0; y < height(); y++) {
            for (int x = 0; x < width(); x++) {
                relaxX(distTo, edgeTo, x, y, x - 1, y + 1);
                relaxX(distTo, edgeTo, x, y, x, y + 1);
                relaxX(distTo, edgeTo, x, y, x + 1, y + 1);
            }
        }

        for (int x = 0; x < width(); x++) {
            if (distTo[seamEnd][height() - 1] > distTo[x][height() - 1]) {
                seamEnd = x;
            }
        }
        verticalSeam[height() - 1] = seamEnd;
        for (int y = height() - 1; y > 0; y--) {
            verticalSeam[y - 1] = edgeTo[verticalSeam[y]][y];
        }
        return verticalSeam;
    }

    /**
     * sequence of indices for horizontal seam.
     */
    public int[] findHorizontalSeam() {
        double[][] distTo = new double[width()][height()];
        int[][] edgeTo = new int[width()][height()];
        int[] horizontalSeam = new int[width()];
        int seamEnd = 0;

        for (int x = 0; x < width(); x++) {
            for (int y = 0; y < height(); y++) {
                if (x == 0) {
                    distTo[x][y] = 1000;
                } else {
                    distTo[x][y] = Double.POSITIVE_INFINITY;
                }
            }
        }

        for (int x = 0; x < width(); x++) {
            for (int y = 0; y < height(); y++) {
                relaxY(distTo, edgeTo, x, y, x + 1, y - 1);
                relaxY(distTo, edgeTo, x, y, x + 1, y);
                relaxY(distTo, edgeTo, x, y, x + 1, y + 1);
            }
        }

        for (int y = 0; y < height(); y++) {
            if (distTo[width() - 1][seamEnd] > distTo[width() - 1][y]) {
                seamEnd = y;
            }
        }

        horizontalSeam[width() - 1] = seamEnd;
        for (int x = width() - 1; x > 0; x--) {
            horizontalSeam[x - 1] = edgeTo[x][horizontalSeam[x]];
        }

        return horizontalSeam;
    }

    private boolean isValid(int x, int y) {
        return x >= 0 && x < width() && y >= 0 && y < height();
    }

    private void relaxX(double[][] distTo, int[][] edgeTo, int x, int y, int nextX, int nextY) {
        if (isValid(nextX, nextY)) {
            double total = distTo[x][y] + energy[nextX][nextY];
            if (total < distTo[nextX][nextY]) {
                edgeTo[nextX][nextY] = x;
                distTo[nextX][nextY] = total;
            }
        }
    }

    private void relaxY(double[][] distTo, int[][] edgeTo, int x, int y, int nextX, int nextY) {
        if (isValid(nextX, nextY)) {
            double total = distTo[x][y] + energy[nextX][nextY];
            if (total < distTo[nextX][nextY]) {
                edgeTo[nextX][nextY] = y;
                distTo[nextX][nextY] = total;
            }
        }
    }

    /** remove horizontal seam from current picture. */
    public void removeHorizontalSeam(int[] seam) {
        if (height() <= 1) {
            throw new java.lang.IllegalArgumentException();
        }

        if (seam == null) {
            throw new java.lang.IllegalArgumentException();
        }

        if (seam.length != width()) {
            throw new java.lang.IllegalArgumentException();
        }

        for (int i = 0; i < seam.length; i++) {
            if (seam[i] < 0 || seam[i] >= height()) {
                throw new java.lang.IllegalArgumentException();
            }

            if (i < seam.length - 1) {
                if (Math.abs(seam[i] - seam[i + 1]) > 1) {
                    throw new java.lang.IllegalArgumentException();
                }
            }
        }

        Picture newPicture = new Picture(width(), height() - 1);
        for (int x = 0; x < width(); x++) {
            int sign = 0;
            for (int y = 0; y < height() - 1; y++) {
                if (y == seam[x]) {
                    sign = 1;
                }
                if (sign == 0) {
                    newPicture.set(x, y, picture.get(x, y));
                } else {
                    newPicture.set(x, y, picture.get(x, y + 1));
                }
            }
        }
        picture = newPicture;
        energy = calcEnergy(picture);
    }



    /** remove vertical seam from current picture. */
    public void removeVerticalSeam(int[] seam) {
        if (width() <= 1) {
            throw new java.lang.IllegalArgumentException();
        }

        if (seam == null) {
            throw new java.lang.IllegalArgumentException();
        }

        if (seam.length != height()) {
            throw new java.lang.IllegalArgumentException();
        }

        for (int i = 0; i < seam.length; i++) {
            if (seam[i] < 0 || seam[i] >= width()) {
                throw new java.lang.IllegalArgumentException();
            }

            if (i < seam.length - 1) {
                if (Math.abs(seam[i] - seam[i + 1]) > 1) {
                    throw new java.lang.IllegalArgumentException();
                }
            }
        }

        Picture newPicture = new Picture(width() - 1, height());
        for (int y = 0; y < height(); y++) {
            int sign = 0;
            for (int x = 0; x < width() - 1; x++) {
                if (x == seam[y]) {
                    sign = 1;
                }
                if (sign == 0) {
                    newPicture.set(x, y, picture.get(x, y));
                } else {
                    newPicture.set(x, y, picture.get(x + 1, y));
                }
            }
        }
        picture = newPicture;
        energy = calcEnergy(newPicture);
    }
}
